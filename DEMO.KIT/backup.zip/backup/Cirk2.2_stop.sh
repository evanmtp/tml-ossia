#!/bin/sh

killall -9 Live
killall -9 Max