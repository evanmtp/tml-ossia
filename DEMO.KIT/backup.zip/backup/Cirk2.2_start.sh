#!/bin/sh

open -a Max /Users/tml/src/tml-ossia/DEMO.KIT/circ.demo.sensors.maxpat
sleep 20
open -a Max2 /Users/tml/src/tml-ossia/DEMO.KIT/circ.demo.sonify.nav.maxpat
sleep 20
open -a Ableton\ Live\ 10\ Suite /Users/tml/src/PVH-cirk/PVH-demo-kit/\#wheeljuggle_8\ Project/#wheeljuggle_8.als